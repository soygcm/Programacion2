// BUnit.h (C) 2008  adolfo@di-mare.com

#error http://www.di-mare.com/adolfo/p/BUnit.htm
#error http://www.di-mare.com/adolfo/p/BUnit/BUnit.zip
#error Falta el archivo BUnit.h

// EOF: BUnit.h