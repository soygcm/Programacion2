var searchData=
[
  ['check_5fok',['check_ok',['../classAcumulador.html#a1358a964d2ca280d53ea0fb98891187d',1,'Acumulador']]]
];
