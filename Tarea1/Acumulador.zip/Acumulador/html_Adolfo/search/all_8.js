var searchData=
[
  ['verifica_5fsuma',['Verifica_Suma',['../classtest__Acumulador.html#a49a869fd069063d4de666d6988539540',1,'test_Acumulador']]]
];
